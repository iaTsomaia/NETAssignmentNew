﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Food.Data;
using Food.Models;
namespace Food.Controllers
{
    public class CartController : Controller
    {
        private CompaniesEntities db = new CompaniesEntities();
        // GET: Cart
        public ActionResult Index(int id)
        {
            order placeOrder = new order();
            placeOrder.orderDetails = (from p in db.Orders
                                       where p.BatchID == id
                                       select p);
            placeOrder.batch = id;
            placeOrder.totalPrice = placeOrder.orderDetails.Sum(x => x.Product.ProductPrice);
            placeOrder.totalTime = placeOrder.orderDetails.Sum(x => x.Product.CookingTimeMinutes);
            return View(placeOrder);
        }

      
        // GET: Companies/Create
        public ActionResult checkCard(int? id)
        {
            order PlaceOrder = new order();
            return View();
        }

        [HttpPost]
        public ActionResult checkCard(Card cardDetails) {

            if (ModelState.IsValid) {
                LuhnCheck checkCardNum = new LuhnCheck();
                if (checkCardNum.LuhnCheckNum(cardDetails.CardNum))
                {
                    string[] dateCard = cardDetails.ExpDate.Split('-');

                    if (int.Parse(dateCard[0]) > DateTime.Now.Year) {
                      
                        return RedirectToAction("orderPlaced");
                    }
                    if (int.Parse(dateCard[0]) ==  DateTime.Now.Year)
                    {
                        if (int.Parse(dateCard[1]) >= DateTime.Now.Month)
                        {
                        //    ViewBag.Message = string.Format("Order Placed!!");
                            return RedirectToAction("orderPlaced");
                        }
                    }
                    }

                }          
            return View(cardDetails);
        }

        public ActionResult orderPlaced() {

            return View(); 
        }
        [HttpPost]
        public ActionResult orderPlaced(Rating rating) {

                var maxBatch = db.Orders.Max(x => x.BatchID); 
                var order = db.Orders.Where(x=>x.BatchID == maxBatch ).FirstOrDefault();
            var orderDet = (from p in db.Orders
                            where p.BatchID == order.BatchID
                            select p);
            var totalPrice = orderDet.Sum(x => x.Product.ProductPrice);
            var identity = System.Web.HttpContext.Current.User.Identity.Name;
            db.PlacedOrders.Add(new PlacedOrder {  Rating = (int)rating.userRating, TotalAmount = (decimal)totalPrice, CompanyID = order.CompanyID_ , UserName = identity});
            db.SaveChanges();
            Company comp = db.Companies.Where(x => x.Id == order.CompanyID_).FirstOrDefault();
            var totalRating = (decimal)(db.PlacedOrders.Where(x => x.CompanyID == order.CompanyID_).Where(p => p.UserName == identity).Sum(x => x.Rating));
            var totalVotes = db.PlacedOrders.Where(x=>x.CompanyID == order.CompanyID_).Where(p => p.UserName == identity).Count();
            comp.TotalRating = totalRating / totalVotes;
            comp.TotalRating = Convert.ToDecimal(string.Format("{0:0.00}", comp.TotalRating));
            db.Entry(comp).Property(x => x.TotalRating).IsModified = true;
            db.Messages.Add(new Message {CompanyID = order.CompanyID_ , MessageText = rating.userComment });
            db.SaveChanges();
            return RedirectToAction("index", "Home");
            
                 
        }

    }


}