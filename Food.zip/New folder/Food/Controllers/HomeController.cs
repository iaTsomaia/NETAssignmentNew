﻿using System.IO;
using System.Linq;
using System.Data.Entity;
using System.Net;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using Food.Data;
using Food.Models;
using System.Reflection;
using System.Security.Principal;

namespace Food.Controllers
{
    public class HomeController : Controller
    {
        private CompaniesEntities db = new CompaniesEntities();
        private compProducts companyProducts = new compProducts();
        public ActionResult Index()
        {
            var companies = db.Companies.Include(c => c.CompanyType).Include(c => c.CompanyPrice);

            return View(companies.ToList());
        }



        // GET
        public ActionResult companypage(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            companyProducts.PassCompanyID = id;

            companyProducts.comp = (from p in db.Companies
                                    where p.Id == id
                                    select p);
            companyProducts.Products = (from p in db.CompanyProducts
                                        where p.CompanyID == id
                                        select p.Product).Include(x => x.ProductCode1);   
            return View(companyProducts);
        }

     
        // POST: CompanyPage
        [HttpPost]
        public ActionResult companypage(string[] products, string HiddenID)
        {
            int batchid = 0;

            if (!(db.Orders.FirstOrDefault() == null))
            {
                batchid = db.Orders.Max(x => x.Id);

            }
            var identity = System.Web.HttpContext.Current.User.Identity.Name;
            var compID = int.Parse(HiddenID) ; 
            int itemID;  
            if (products != null)
            { 
                foreach (string item in products)
                {
                    
                    if (item != "false")
                    { 
                        itemID = int.Parse(item); 
                        db.Orders.Add(new Order { ProductID = itemID, BatchID = batchid, userName_ = identity , CompanyID_ =(int) compID});
                        db.SaveChanges();
                    }
                }
                }

                return RedirectToAction("Index", "cart", new { id = batchid});
            

        }

        public ActionResult Reviews(int? id)
        {
            var review = db.Messages.Where(x=>x.CompanyID ==id);
            
            return View(review);
        }


    }
}