﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Food.Data;

namespace Food.Controllers
{
    public class PlacedOrdersController : Controller
    {
        private CompaniesEntities db = new CompaniesEntities();

        // GET: PlacedOrders
        public ActionResult Index()
        {
            return View(db.PlacedOrders.ToList());
        }

        // GET: PlacedOrders/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PlacedOrder placedOrder = db.PlacedOrders.Find(id);
            if (placedOrder == null)
            {
                return HttpNotFound();
            }
            return View(placedOrder);
        }

        // GET: PlacedOrders/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: PlacedOrders/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,TotalAmount,Currdate,Rating,status")] PlacedOrder placedOrder)
        {
            
                db.PlacedOrders.Add(placedOrder);
                db.SaveChanges();
                return RedirectToAction("Index");
            
       
        }

        // GET: PlacedOrders/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PlacedOrder placedOrder = db.PlacedOrders.Find(id);
            if (placedOrder == null)
            {
                return HttpNotFound();
            }
            return View(placedOrder);
        }

        // POST: PlacedOrders/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,TotalAmount,Currdate,Rating,status")] PlacedOrder placedOrder)
        {
            if (ModelState.IsValid)
            {
                db.Entry(placedOrder).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(placedOrder);
        }

        // GET: PlacedOrders/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PlacedOrder placedOrder = db.PlacedOrders.Find(id);
            if (placedOrder == null)
            {
                return HttpNotFound();
            }
            return View(placedOrder);
        }

        // POST: PlacedOrders/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PlacedOrder placedOrder = db.PlacedOrders.Find(id);
            db.PlacedOrders.Remove(placedOrder);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
