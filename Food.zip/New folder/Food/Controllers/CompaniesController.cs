﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using Food.Data;
using Food.Models; 
namespace Food.Controllers
{
    public class CompaniesController : Controller
    {
        private CompaniesEntities db = new CompaniesEntities();

        // GET: Companies
        public ActionResult Index()
        {
            var companies = db.Companies.Include(c => c.CompanyType).Include(c => c.CompanyPrice);
            return View(companies.ToList());
        }

        // GET: Companies/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var company = db.Companies.Find(id);
            if (company == null)
            {
                return HttpNotFound();
            }
            return View(company);
        }

        // GET: Companies/Create
        public ActionResult Create()
        {
            ViewBag.TypeID = new SelectList(db.CompanyTypes, "TypeID", "Type");
            ViewBag.PricesID = new SelectList(db.CompanyPrices, "CompanyPricesID", "Prices");
            return View();
        }

        // POST: Companies/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Name,Description,TypeID,ImagePath,PricesID")] Company company, HttpPostedFileBase logo)
        {
            if (ModelState.IsValid)
            {
                if (logo != null)
                {
                    var extension = Path.GetExtension(logo.FileName);
                    String logoNameFull;
                    if (db.Companies.FirstOrDefault() != null)
                       logoNameFull = db.Companies.Max(i=> i.Id + 1).ToString() + extension;
                    else
                        logoNameFull = "0" + extension;

                    company.ImagePath = "/Data/Logo/" + logoNameFull;
 
                    logo.SaveAs(Path.Combine(Server.MapPath("~/Data/Logo/"), logoNameFull));
                }


                db.Companies.Add(new Company { Name = company.Name, Description = company.Description, TypeID = company.TypeID, ImagePath = company.ImagePath, PricesID = company.PricesID });
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.TypeID = new SelectList(db.CompanyTypes, "TypeID", "Type", company.TypeID);
            ViewBag.PricesID = new SelectList(db.CompanyPrices, "CompanyPricesID", "Prices", company.PricesID);
            return View(company);
        }

        // GET: Companies/EditCompany/5
        public ActionResult EditCompany(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            InsertCompanies ic = new InsertCompanies();
            ic.comp = db.Companies.Find(id);
            ic.PassCompanyID = id; 
            if (ic.comp == null)
            {
                return HttpNotFound();
            }
            ViewBag.Type = new SelectList(db.CompanyTypes, "TypeID", "Type");
            ViewBag.Prices = new SelectList(db.CompanyPrices, "CompanyPricesID", "Prices");
            return View(ic);
        }

        // POST: Companies/EditCompany/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditCompany( InsertCompanies company)
        {
            if (ModelState.IsValid)
            {
                company.comp.Id = (int)company.PassCompanyID;
                db.Entry(company.comp).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.TypeID = new SelectList(db.CompanyTypes, "TypeID", "Type", company.comp.TypeID);
            ViewBag.PricesID = new SelectList(db.CompanyPrices, "CompanyPricesID", "Prices", company.comp.PricesID);
            return View(company);
        }

        // GET: Companies/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Company company = db.Companies.Find(id);
            if (company == null)
            {
                return HttpNotFound();
            }
            return View(company);
        }

        // POST: Companies/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Company company = db.Companies.Find(id);
            var cproduct = db.CompanyProducts.Where(p=>p.CompanyID == id);
            db.CompanyProducts.RemoveRange(cproduct);
            var orders = db.Orders.Where(p => p.CompanyID_ == id);
            var placedOrders = db.PlacedOrders.Where(p => p.CompanyID == id);
            db.Orders.RemoveRange(orders);
            db.PlacedOrders.RemoveRange(placedOrders);
            db.Companies.Remove(company);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
