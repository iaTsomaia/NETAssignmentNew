﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Food.Data;
using Food.Models;

namespace Food.Controllers
{
    public class ProductsController : Controller
    {
        private CompaniesEntities db = new CompaniesEntities();
        private compProducts companyProducts = new compProducts();


        // GET: Products
        public ActionResult Index(int? id)
        {
              companyProducts.PassCompanyID = id;
              
                                         
              companyProducts.Products = (from p in db.CompanyProducts
                                          where p.CompanyID == id
                                          select p.Product).Include(x=>x.ProductCode1);
            return View(companyProducts);
        }

        // GET: Products/Details/5
        public ActionResult Details(int? id, int? id2)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            InsertProducts companyProduct = new InsertProducts();
            companyProduct.PassProductID = id;
            companyProduct.PassCompanyID = id2; 
            companyProduct.Products = db.Products.Find(id);
            if (companyProduct == null)
            {
                return HttpNotFound();
            }
            return View(companyProduct);
        }

        // GET: Products/Create
        public ActionResult Create(int? id)
        {
            InsertProducts ins = new InsertProducts();
            ins.PassCompanyID = id; 
            ViewBag.ProductCode =  new SelectList(db.ProductCodes, "ProductCode1", "ProductName");
            ViewBag.ProductCategoryID = new SelectList(db.ProductCategories, "ProductCategoryID", "ProductCategoryName");
            return View(ins);
        }

        // POST: Products/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(InsertProducts insertP)
        {
            if (ModelState.IsValid)
            {
               db.Products.Add(new Product { ProductCode = insertP.Products.ProductCode, CookingTimeMinutes = insertP.Products.CookingTimeMinutes, ProductCategoryID= insertP.Products.ProductCategoryID, ProductPrice = insertP.Products.ProductPrice });
               db.SaveChanges();
               var ProdID = db.Products.Max(x => x.ProductID);
               int compID = (int) insertP.PassCompanyID;
                //    db.Products.FirstOrDefault(u => u.ProductID == nextID).Companies.FirstOrDefault(f => f.Id == compID);           
                db.CompanyProducts.Add(new CompanyProduct {ProductID = ProdID, CompanyID = compID});
                db.SaveChanges();
               return RedirectToAction("Index", new { id = compID });

            }
             ViewBag.ProductCode = new SelectList(db.ProductCodes, "ProductCode1", "ProductName", insertP.Products.ProductCode);
             ViewBag.ProductCategoryID = new SelectList(db.ProductCategories, "ProductCategoryID", "ProductCategory", insertP.Products.ProductCategoryID);

            return View(insertP);
        }

        // GET: Products/Edit/5
        public ActionResult Edit(int? id, int id2)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            InsertProducts companyProduct = new InsertProducts();
            companyProduct.PassProductID = id;
            companyProduct.PassCompanyID = id2;
            companyProduct.Products =  db.Products.Find(id);
            if (companyProduct == null)
            {
                return HttpNotFound();
            }
            ViewBag.ProductCode = new SelectList(db.ProductCodes, "ProductCode1", "ProductName");
            ViewBag.ProductCategoryID = new SelectList(db.ProductCategories, "ProductCategoryID", "ProductCategoryName");
            return View(companyProduct);
        }

        // POST: Products/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(InsertProducts iproducts)
        {
            if (ModelState.IsValid)
            {
                iproducts.Products.ProductID = (int)iproducts.PassProductID; 
                db.Entry(iproducts.Products).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", new { id = iproducts.PassCompanyID });
                
            }
            ViewBag.CompanyID = new SelectList(db.Companies, "Id", "Name", iproducts.Products.ProductID);
            ViewBag.ProductID = new SelectList(db.Products, "ProductID", "ProductID", iproducts.Products.ProductID);
            return View(iproducts);
        }

        // GET: Products/Delete/5
        public ActionResult Delete(int? id, int? id2)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            InsertProducts companyProduct = new InsertProducts();
            companyProduct.Products= db.Products.Find(id);
            companyProduct.PassCompanyID = id2;
            if (companyProduct == null)
            {
                return HttpNotFound();
            }
            return View(companyProduct);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id, int? id2)
        {

            InsertProducts companyProduct = new InsertProducts();
            companyProduct.Products=  db.Products.Find(id);
            companyProduct.PassCompanyID = id2;
            var cproduct = db.CompanyProducts.Where(p => p.ProductID == id);
            db.CompanyProducts.RemoveRange(cproduct);
            db.Products.Remove(companyProduct.Products);
            db.SaveChanges();
            return RedirectToAction("Index", new {id= companyProduct.PassCompanyID });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
