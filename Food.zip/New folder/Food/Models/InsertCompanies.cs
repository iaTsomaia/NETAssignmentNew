﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Food.Data; 
namespace Food.Models
{
    public class InsertCompanies
    {
        public Company comp { get; set; }
        public int? PassCompanyID { get; set; }
    }
}