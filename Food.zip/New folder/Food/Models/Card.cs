﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Food.Models
{
    public class Card
    {
        [Required]
        public String CardNum { get; set; }
        [Required]
        public String ExpDate { get; set; }
        [Required]
        public int CvCode { get; set; }
    }
}