﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Food.Data; 
namespace Food.Models
{
    public class order
    {
        public decimal? totalPrice { get; set; }
        public int? totalTime { get; set; }
        public IQueryable<Order>  orderDetails { get; set; }
        public int? batch { get; set; }
    }
}