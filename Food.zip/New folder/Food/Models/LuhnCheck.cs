﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Food.Models
{
    public class LuhnCheck
    {
        
            private readonly int[] results = new[] { 0, 2, 4, 6, 8, 1, 3, 5, 7, 9 };
       
            private bool CheckDigits(int[] digits)
            {
                for (int i = digits.Length % 2; i < digits.Length; i += 2)
                {
                    digits[i] = results[digits[i]];
                }

                return digits.Sum() % 10 == 0;
            }


            public bool LuhnCheckNum(string cardNumber)
            {
                if (string.IsNullOrEmpty(cardNumber))
                {
                    throw new ArgumentNullException("cardNumber");
                }

                int[] digits = cardNumber.Select(c => c - '0').ToArray();

                if (digits.Sum() == 0)
                {
                    return false;
                }

                return CheckDigits(digits);
            }
        }
    }
