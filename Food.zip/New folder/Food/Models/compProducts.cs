﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Food.Data;


namespace Food.Models
{
    public class compProducts
    {
        public IQueryable<Product> Products { get; set; }
        public IQueryable<Company>     comp { get; set; }
        public ProductCode ProdName { get; set; }
        public int? PassCompanyID { get; set; }
    }

}