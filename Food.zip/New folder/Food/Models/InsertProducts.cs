﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Food.Data; 
namespace Food.Models
{
    public class InsertProducts
    {

        public Product                       Products { get; set; }
        public ProductCode                     Pcodes { get; set; }
        public int?                     PassCompanyID { get; set; }
        public int?                     PassProductID { get; set; }



    }
}