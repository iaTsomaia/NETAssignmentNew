﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Food.Models
{
    public class Rating
    {
        public int userRating { get; set; }
        public String userComment { get; set; }
        public int id { get; set; }
        public int companyID { get; set; }
    }
}