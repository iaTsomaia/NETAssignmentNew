﻿INSERT INTO [dbo].[ProductCodes](ProductName) VALUES('Tea');
INSERT INTO [dbo].[ProductCodes](ProductName) VALUES('Coffee');
INSERT INTO [dbo].[ProductCodes](ProductName) VALUES('Chocolate');


INSERT INTO [dbo].[ProductCategory](ProductCategoryName) VALUES('Drinks');
INSERT INTO [dbo].[ProductCategory](ProductCategoryName) VALUES('Snacks');


